﻿class Program
{
    public static void Main(string[] args)
    {
        int[] array = { 3, 6, 9, 12, 15 };
    }

    public static void SortArray(int[] array)
    {
        Array.Sort(array);

    }

    public static void doubleArray(int[] array)
    {
        //int[] array2 = new int[array.Length;
        //Array.Copy(array,array2, array.Length);
        for(int i = 0; i < array.Length; i++)
        {
            //array2[i] *= 2;
            array[i] *= 2;
        }
    }

    public static void printArray(int[] array)
    {
        foreach(int i in array)
        {
            Console.WriteLine(i);
        }
    }
}