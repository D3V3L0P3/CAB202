﻿class Program
{
    public static void Main(string[] vars)
    {
        int n = 10;
        Console.WriteLine($"n: {n}");
        Console.WriteLine($"----------");

        Console.WriteLine("Control");
        String n1 = Next(n);
        Console.WriteLine($"n1: {n1}");

        Console.WriteLine($"----------");
        Console.WriteLine("Ref");
        String n2 = NextRef(ref n);
        Console.WriteLine($"n: {n}\tn2: {n2}");

        Console.WriteLine($"----------");
        int m;
        Console.WriteLine("Out");
        String n3 = NextOut(out m);
        Console.WriteLine($"m: {m}\tn2: {n3}");
    }
    
    public static string Next(int n)
    {
        n++;
        return n.ToString();
    }

    public static string NextRef(ref int n)
    {
        n++;
        return n.ToString();
    }

    public static string NextOut(out int n)
    {
        n = 10;
        n++;
        return n.ToString();
    }

}