﻿using System;

namespace QuestionEleven
{
    class program
    {
        static void Main(int[] args)
        {


        }

        static void GetInputs()
        {
            // will accept 3 doubles which represent width length and height
            //assumed room is rectangular with 4 walls, all values to be input by user

            string input;
            double height;
            double length;
            double width;


            Console.Write("Enter height");
            input = Console.ReadLine();
            double.TryParse(input, out height);

            Console.Write("Enter Width");
            input = Console.ReadLine();
            double.TryParse(input, out width);

            Console.Write("Enter Length");
            input = Console.ReadLine();
            double.TryParse(input, out length);
        }

        static void PaintRoom()
        {
            //determine the cost to paint room, $10/m^2
        }

        static void OutputPainting()
        {
            // will output cost of painting
        }


    }

}