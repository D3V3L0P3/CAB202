﻿using System;

    namespace Array
    {
        class Program
        {
            static void Main(string[] args)
            {
            Console.Write("Please enter the length if the array: ");
            Int32.TryParse(Console.ReadLine(), out var len);
            
            int[] array = GeneateArray(len);

            foreach(int i in array)
            {
                Console.WriteLine(i);
            }

            double avg = AverageArray(array);
            Console.WriteLine($"The average is {avg}");
            
            }

            static int[] GeneateArray(int length)
            {
                Random rng = new Random();

                int[] array = new int[length];

                for (int i = 0; i < length; i++)
                {
                    array[i] = rng.Next(0, 100);
                }
                
                return array;
            }
            
            static double AverageArray(int[] array)
            {
                double total = 0;

                foreach (int n in array)
                {
                    total += n;
                }

                return total / array.Length;
            }

        }
    }