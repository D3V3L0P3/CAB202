﻿using System;

namespace MethdDemo
{
    internal class program
    {
        static void Main(string[] args)
        {
            Console.Write("Please enter a number: ");
            Int32.TryParse(Console.ReadLine(), out var num);
            Console.WriteLine(MilesToKilometres(num));
        }

        static int Factorial(int n)
        {
            int total = 1;

            for (int i = 2; i <= n; i++)
            {
                total *= i;
            }

            return total;
        }

        static double MilesToKilometres(double miles);
        {
            miles * 1.60934
            return MilesToKilometres;
        }
    }
}