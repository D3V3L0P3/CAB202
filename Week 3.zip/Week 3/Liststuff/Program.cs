﻿namespace Arrays
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> nums = new List<int>();

            for (int i = 0; i < args.Length; i++)
            {
                nums.Add(i);
            }

            foreach (int n in nums) 
            {
                Console.WriteLine(n);
            }

        }
    }
}