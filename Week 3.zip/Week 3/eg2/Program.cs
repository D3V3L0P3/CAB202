﻿namespace CheckPostcodes
{

    class Program
    {

        static void Main3(string[] args)
        {
            
            int[] PostCodes = { 4210, 4211, 4169, 4002, 4212, 4000, 4005, 4008, 4124, 4153 };

            Console.Write("Enter a PostCode to check! ");

            //Int32.TryParse(Console.ReadLine(), out int input);

            foreach(int C in PostCodes)
            {
                
                Console.Write(C);

            }


        }

    }

}