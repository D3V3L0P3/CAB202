﻿namespace arrays
{

    class Program
    {

        static void Main2(string[] args)
        {
            // setup variables
            int limit;
            int[] array;

            // get user input
            Console.Write("Please enter a limit: ");

            bool success = int.TryParse(Console.ReadLine(), out limit); 
            
            //if num given 
            if (success)
            {
                //setup array
                array = new int[limit];

                //prompt the user
                Console.WriteLine($"Please enter {limit} numbers");

   
                int input;

                for (int i = 0; i < limit; i++)
                {
                    input = 0;

                    bool success2 = int.TryParse(Console.ReadLine(), out input);

                    array[i] = input;
                }

                int total = 0;

                Console.WriteLine("You entered:");
                // print array
                for (int i = 0; i < limit; i++) 
                {
                    Console.Write($"{array[i]} ");
                    total += array[i]; // shorthand for total + array[i]
                }

                Console.WriteLine($"\nTotal:\t{total}");
                Console.WriteLine($"Mean:\t{total / limit}");
            }

        }
    }
}