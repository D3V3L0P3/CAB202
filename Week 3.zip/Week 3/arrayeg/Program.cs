﻿namespace Arrays
{

    class Program
    {

        static void Main(string[] args)
        {

            int[] nums = new int[5];
            nums = { 23, 53, 16, 46, 12};

            foreach(int n in nums)
            {
                Console.WriteLine(n);
            }

            Array.Sort(nums);
            Array.Reverse(nums);
            Console.WriteLine("---------------");

            foreach (int n in nums)
            {
                Console.Write(n);
            }
        }
    }
}