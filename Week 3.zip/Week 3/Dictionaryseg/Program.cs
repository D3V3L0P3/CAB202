﻿namespace Arrays
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, int> FeeTable = new Dictionary<string, int>();

            FeeTable.Add("UK", 100);
            FeeTable.Add("USA", 300);
            FeeTable.Add("FRANCE", 200);
            FeeTable.Add("Chille", 500);
            FeeTable.Add("China", 1000);
            FeeTable.Add("Egypt", 600);

            string country = Console.ReadLine();

            //FeeTable.TryGetValue(country, out int fee);
            {
                Console.WriteLine($"{country} : {FeeTable[country]}");
            }

        }
    }
}